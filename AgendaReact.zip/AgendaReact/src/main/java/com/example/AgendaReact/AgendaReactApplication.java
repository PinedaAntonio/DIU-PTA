package com.example.AgendaReact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaReactApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendaReactApplication.class, args);
	}

}
