package com.example.hotel.Modelo.Repository.Impl;

public enum regimen {
    ALOJAMIENTO_Y_DESAYUNO,
    MEDIA_PENSION,
    PENSION_COMPLETA
}
