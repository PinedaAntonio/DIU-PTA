package com.example.hotel.Modelo.Repository.Impl;

public enum tipoHabitacion {
    DOBLE_USO_INDIVIDUAL,
    DOBLE,
    JUNIOR_SUITE,
    SUITE
}
