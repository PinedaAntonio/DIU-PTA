package com.example.examen_ev1_pta.Controller;

import com.example.examen_ev1_pta.MainApp;

public class PrincipalController {
    private MainApp mainApp;

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }
}
