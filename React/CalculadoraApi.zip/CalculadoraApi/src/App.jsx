import { useState } from "react";
import * as math from "mathjs";
import "./App.css";
import Calculadora from "./components/Calculadora";

function App() {
  // Hacemos dos variables para poder alternar entre la expresión y el resultado
  const [expresion, setExpression] = useState(""); // Estado para manejar la expresión actual
  const [result, setResult] = useState("0"); // Estado para manejar el resultado calculado

  const handleInput = (input) => {
    if (input === "toggleSign") {
      if (expresion === "") return;
      const nuevaExpresion = expresion.startsWith("-")
        ? expresion.slice(1)
        : "-" + expresion;
      setExpression(nuevaExpresion);
    } else {
      setExpression((prev) => prev + input); // Concatenar la entrada a la expresión actual
    }
  };

  const handleEquals = async () => {
    if (expresion === "" || result === "Error") return;
  
    try {
      const operacion = encodeURIComponent(expresion);
      const response = await fetch(`https://api.mathjs.org/v4/?expr=${operacion}`); 
  
      if (!response.ok) {
        throw new Error(response.statusText);
      }
  
      const resultado = await response.text(); // Obtener el resultado como texto
      setResult(resultado); // Actualizar el estado con el resultado
      setExpression(resultado); // Reiniciar la expresión con el resultado
    } catch (error) {
      setResult("Error"); // Mostrar "Error" en caso de error con la API
      setExpression("");
      console.error("Error al calcular la expresión:", error);
    }
  };
  
  

  const handleClear = () => {
    setExpression("");
    setResult("0");
  };

  return (
    <div className="app">
      <div className="display">
        <h1>{expresion || result}</h1> {/* Mostrar la expresión o el resultado */}
      </div>
      <Calculadora
        onInput={handleInput}
        onEquals={handleEquals}
        onClear={handleClear}
      />
    </div>
  );
}

export default App;
