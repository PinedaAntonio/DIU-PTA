package com.example.agenda.controller;

import com.example.agenda.MainApp;

public class PrincipalController {
    private MainApp mainApp;

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

}
